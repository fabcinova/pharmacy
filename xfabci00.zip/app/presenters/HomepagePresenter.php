<?php

/**
 * Homepage presenter.
 */
class HomepagePresenter extends BasePresenter
{       
}
